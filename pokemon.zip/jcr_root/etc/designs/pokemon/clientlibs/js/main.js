$(document).ready(function() {
    pokemonList("https://pokeapi.co/api/v2/pokemon/?limit=151");

    $('#nextList').click(function() {



        var currentView = $('.pokemon-row.current');
        var nextView = currentView.next('.pokemon-row');
        window.scrollTo(0, 0);

        nextView.addClass('current');
        nextView.removeClass('hidden');
        currentView.addClass('hidden');
        currentView.removeClass('current');

        $('#previousList').prop('disabled', false);
        if (nextView.next('.row').length == 0) {

            $('#nextList').prop('disabled', true);
        }

    });


    $('#previousList').click(function() {



        var currentView = $('.pokemon-row.current');
        var previousView = currentView.prev('.pokemon-row');
        window.scrollTo(0, 0);
        previousView.addClass('current');
        previousView.removeClass('hidden');
        currentView.addClass('hidden');
        currentView.removeClass('current');
        $('#nextList').prop('disabled', false);
        if (previousView.prev('.pokemon-row').length == 0) {

            $('#previousList').prop('disabled', true);
        }

    });
});



function pokemonList(pokemonUrl) {
    $.ajax({
        url: pokemonUrl,
        context: document.body,
        success: function(data) {
            var results = data.results;
            var content = "";
            var pageNumber = 0;
            for (var x = 0; x < results.length; x++) {

                var number = x + 1;
                var pagefactor = x % 20;

                if (x === 0 || pagefactor === 0) {
                    pageNumber++;
                    if (x === 0) {
                        content += "<div class=\" row pokemon-row current page-" + pageNumber + "\">";
                    } else {
                        content += "<div class=\" row pokemon-row hidden page-" + pageNumber + "\">";
                    }
                }
                content += "<div class = \"col-xs-12 col-md-6 col-sm-6 col-lg-3 pokemonUnit\"><img class=\"col-xs-6 col-sm-12\" src=\"/content/dam/pokemon/" + number + ".png\"/>";
                content += "<div class=\"details col-xs-6 col-sm-12\"><h3 class=\"number\">#" + formatNumber(number) + "</h3> <h3 class=\"name\">" + results[x].name + "</h3></div></div>";

                if (pagefactor === 19) {
                    content += "</div>";
                }
                if (x == 150)
                    break;
            }

            $(content).appendTo("#pokemonList");

            $('#previousList').prop('disabled', true);

        }
    });
};

function formatNumber(num) {
    var characters = num.toString().length;

    if (characters == 1) {

        return '00' + num;
    } else if (characters == 2) {
        return '0' + num;
    } else {
        return num;
    }

}

function searchFunction() {
    var input, filter, h, i;
    input = document.getElementById('searchPokemon');
    filter = input.value.toUpperCase();
    var pages = $('.pokemon-list .pokemon-row');
    var current = $('.pokemon-list .pokemon-row.current');
    var pokemonUnits = $('.pokemonUnit');

    for (i = 0; i < pokemonUnits.length; i++) {
        h = pokemonUnits[i].getElementsByClassName("name")[0];
        if (h.innerHTML.toUpperCase().indexOf(filter) > -1) {
            console.log(filter);
            if (filter == '') {
                if ($('.pokemon-row.current').next('.pokemon-row').length == 1) {

                    $('#nextList').prop('disabled', false);
                }

                if ($('.pokemon-row.current').prev('.pokemon-row').length == 1) {

                    $('#previousList').prop('disabled', false);
                }


                pages.addClass('hidden');
                pages.addClass('row');
                current.removeClass('hidden');

            } else {
                pages.removeClass('hidden');
                pages.removeClass('row');
                $('#previousList').prop('disabled', true);
                $('#nextList').prop('disabled', true);
            }
            pokemonUnits[i].style.display = "";

        } else {
            pokemonUnits[i].style.display = "none";
        }

    }
}